package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/rand"
	scanner "distributed-scan/scannerBuf"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"

	"github.com/elastic/go-elasticsearch/v8"
	"github.com/elastic/go-elasticsearch/v8/esapi"
)

// Generate a random UUID-like string
func generateID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])
}

// Reads IPs from file
func loadActiveHosts() []string {
	f, err := os.Open(activeHostsFile)
	if err != nil {
		fmt.Println("[!] Could not open active hosts file:", err)
		return nil
	}
	defer f.Close()

	var hosts []string
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			hosts = append(hosts, line)
		}
	}
	return hosts
}

// Executes nmap scan and parses XML output
func runNmap(ip, method, ports string) ([]PortInfo, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeoutSeconds*time.Second)
	defer cancel()

	// Added -oX - to output XML to stdout
	cmd := exec.CommandContext(ctx, "nmap", method, "-p", ports, "--open", "-sV", "--script", "ssl-cert,http-headers,banner", "-Pn", "-oX", "-", ip)
	output, err := cmd.CombinedOutput()

	if ctx.Err() == context.DeadlineExceeded {
		return nil, fmt.Errorf("timeout on: %s %s", ip, method)
	}
	if err != nil {
		// Nmap can exit with a non-zero status even with valid output (e.g., if no hosts were up)
		// We'll log the error but still try to parse the output.
		logf("%s[!]%s Nmap error on %s %s: %v\n", ColorRed, ColorReset, ip, method, err)
	}

	var nmapRun NmapRun
	if err := xml.Unmarshal(output, &nmapRun); err != nil {
		return nil, fmt.Errorf("failed to parse nmap XML for %s %s: %w. Output: %s", ip, method, err, string(output))
	}

	var results []PortInfo
	for _, host := range nmapRun.Hosts {
		for _, port := range host.Ports {
			if port.State.State != "open" {
				continue // We only care about open ports since we use --open
			}

			portInfo := PortInfo{
				Extrainfo:          "None",
				FingerprintStrings: "",
				HTTPHeaders:        "",
				HTTPServerHeader:   "",
				IconHash:           "None",
				Port:               fmt.Sprintf("%d", port.PortID),
				Product:            port.Service.Product,
				Protocol:           port.Protocol,
				Service:            port.Service.Name,
				State:              port.State.State,
				Version:            port.Service.Version,
			}

			// Process scripts
			for _, script := range port.Scripts {
				switch script.ID {
				case "http-headers":
					portInfo.HTTPHeaders = script.Output
				case "http-server-header":
					portInfo.HTTPServerHeader = script.Output
				case "fingerprint-strings":
					portInfo.FingerprintStrings = script.Output
				case "ssl-cert":
					portInfo.SSLCert = script.Output
				case "banner":
					portInfo.Banner = script.Output
				}
			}

			// Set default values for empty fields
			if portInfo.Product == "" {
				portInfo.Product = "None"
			}
			if portInfo.Version == "" {
				portInfo.Version = "None"
			}
			if portInfo.HTTPServerHeader == "" {
				portInfo.HTTPServerHeader = "<empty>"
			}

			results = append(results, portInfo)
		}
	}

	return results, nil
}

// Scans one host (TCP and UDP) and sends results to a channel
func scanHost(ip string, wg *sync.WaitGroup, sem chan struct{}, resultsChan chan<- HostResult) {
	defer wg.Done()
	sem <- struct{}{}
	defer func() { <-sem }()

	logf("\n%s[+]%s Scanning host: %s%s%s\n", ColorGreen, ColorReset, ColorCyan, ip, ColorReset)

	var allPorts []PortInfo

	// TCP Scan
	logf(" -> TCP Scan (-sT): %s\n", ip)
	tcpResults, err := runNmap(ip, "-sT", tcpPorts)
	if err != nil {
		logf("%s[!]%s Error during TCP scan for %s: %v\n", ColorRed, ColorReset, ip, err)
	} else {
		allPorts = append(allPorts, tcpResults...)
	}

	// Note: UDP scanning requires root privileges, so we'll skip it for now
	// UDP Scan
	// logf(" -> UDP Scan (-sU): %s\n", ip)
	// udpResults, err := runNmap(ip, "-sU", udpPorts)
	// if err != nil {
	// 	logf("%s[!]%s Error during UDP scan for %s: %v\n", ColorRed, ColorReset, ip, err)
	// } else {
	// 	allPorts = append(allPorts, udpResults...)
	// }

	// Create host result
	hostResult := HostResult{
		CPEs:    "None",
		CVEs:    "None",
		Code:    "ae",
		Domain:  "None",
		IP:      ip,
		Ports:   allPorts,
		Tags:    "None",
		ID:      generateID(),
		Scanned: true,
	}

	resultsChan <- hostResult
}

// Thread-safe logger
func logf(format string, a ...any) {
	printLock.Lock()
	defer printLock.Unlock()
	fmt.Printf(format, a...)
}

// Prints a result to the console with beautiful colors
func printResult(result HostResult) {
	printLock.Lock()
	defer printLock.Unlock()

	fmt.Printf("%s[HOST]%s %s%s%s - %d ports found\n",
		ColorGreen, ColorReset,
		ColorCyan, result.IP, ColorReset,
		len(result.Ports),
	)

	for _, port := range result.Ports {
		serviceInfo := port.Service
		if port.Product != "None" {
			serviceInfo += " (" + port.Product
			if port.Version != "None" {
				serviceInfo += " " + port.Version
			}
			serviceInfo += ")"
		}

		fmt.Printf("  %s[PORT]%s %s:%s%s/%s%s - %s%s%s - %s\n",
			ColorGreen, ColorReset,
			result.IP,
			ColorYellow, port.Port, ColorReset,
			strings.ToUpper(port.Protocol),
			ColorCyan, port.State, ColorReset,
			serviceInfo,
		)
	}
}
func createIndex(es *elasticsearch.Client, indexName, body string) {
	var res *esapi.Response
	var err error

	if body == "" {
		// Create index with default settings
		req := esapi.IndicesCreateRequest{
			Index: indexName,
		}
		res, err = req.Do(context.Background(), es)
	} else {
		// Create index with custom settings and mapping
		req := esapi.IndicesCreateRequest{
			Index: indexName,
			Body:  strings.NewReader(body),
		}
		res, err = req.Do(context.Background(), es)
	}

	if err != nil {
		log.Printf("Error creating index %s: %s", indexName, err)
	}
	defer res.Body.Close()

	if res.IsError() {
		if res.StatusCode == 400 && strings.Contains(res.String(), "resource_already_exists_exception") {
			log.Printf("Index '%s' already exists. Skipping creation.", indexName)
		} else {
			log.Fatalf("[%s] Error creating index %s: %s", res.Status(), indexName, res.String())
		}
	} else {
		log.Printf("Index '%s' created successfully.", indexName)
	}
}

var on sync.Once

func checkIndexExists(es *elasticsearch.Client, indexName string) error {
	req := esapi.IndicesExistsRequest{
		Index: []string{indexName},
	}
	res, err := req.Do(context.Background(), es)
	if err != nil {
		return fmt.Errorf("error checking index existence for %s: %s", indexName, err)
	}
	defer res.Body.Close()

	if res.StatusCode == 200 {
		return fmt.Errorf("index '%s' exists ", indexName)
	} else if res.StatusCode == 404 {
		return fmt.Errorf("index '%s' does NOT exist ", indexName)
	} else {
		return fmt.Errorf("[%s] Unexpected status when checking index %s: %s", res.Status(), indexName, res.String())
	}
}

// Indexes a HostResult into Elasticsearch
func indexResultToES(es *elasticsearch.Client, result HostResult) {
	data, err := json.Marshal(result)
	if err != nil {
		logf("%s[!]%s Failed to marshal result for ES: %v\n", ColorRed, ColorReset, err)
		return
	}
	on.Do(func() {
		if err := checkIndexExists(es, "port_scan_results"); err != nil {
			createIndex(es, "port_scan_results", "")
			log.Println(err)
		}
	})

	req := esapi.IndexRequest{
		Index:      "port_scan_results",
		Body:       bytes.NewReader(data),
		Refresh:    "true",
		DocumentID: generateID(),
	}

	res, err := req.Do(context.Background(), es)
	if err != nil {
		logf("%s[!]%s Failed to index result to ES: %v\n", ColorRed, ColorReset, err)
		return
	}
	defer res.Body.Close()
	if res.IsError() {
		logf("%s[!]%s Error response from ES: %s\n", ColorRed, ColorReset, res.String())
	}
}

func convertToHostList(hostMap map[string]map[string]bool) *scanner.HostList {
	hostList := &scanner.HostList{
		Hosts: make(map[string]*scanner.HostList_HostInfo),
	}

	for host, ports := range hostMap {
		hostInfo := &scanner.HostList_HostInfo{
			Ports: make(map[string]bool),
		}
		for port, isOpen := range ports {
			hostInfo.Ports[port] = isOpen
		}
		hostList.Hosts[host] = hostInfo
	}

	return hostList
}

func convertFromHostList(hostList *scanner.HostList) map[string]map[string]bool {
	hostMap := make(map[string]map[string]bool)

	for host, hostInfo := range hostList.Hosts {
		portMap := make(map[string]bool)
		for port, isOpen := range hostInfo.Ports {
			portMap[port] = isOpen
		}
		hostMap[host] = portMap
	}

	return hostMap
}
