package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"net/http"
	"sync"
	"time"

	scanner "distributed-scan/scannerBuf"

	"github.com/elastic/go-elasticsearch/v8"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type portScannerServer struct {
	scanner.UnimplementedPortScannerServer
	discoveryClient scanner.HostDiscoveryClient
}

func newDiscoveryClient(discoveryServiceAddr string) (scanner.HostDiscoveryClient, error) {
	conn, err := grpc.Dial(discoveryServiceAddr,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithTimeout(5*time.Second))
	if err != nil {
		return nil, err
	}
	return scanner.NewHostDiscoveryClient(conn), nil
}

func (s *portScannerServer) getHostsFromDiscoveryService() (*scanner.HostList, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	return s.discoveryClient.DiscoverHosts(ctx, &scanner.NetworkRange{
		// Use either cidr or file_path depending on your proto definition
		Cidr: "file", // This signals we want file-based discovery
	})
}
func (s *portScannerServer) ScanPorts(ctx context.Context, req *scanner.ScanRequest) (*scanner.PortResults, error) {
	hostList, err := s.getHostsFromDiscoveryService()
	if err != nil {
		return nil, fmt.Errorf("failed to get hosts: %v", err)
	}

	cfg := elasticsearch.Config{
		Addresses: []string{
			"https://localhost:9200",
		},
		APIKey: "cFpwSU41Z0JwMXJ4ZGhnbE0yMHE6bms0UmdfYl9jel80QTE0ZGpNR1RYdw==",
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		},
	}

	es, err := elasticsearch.NewClient(cfg)
	if err != nil {
		logf("%s[!]%s Could not create Elasticsearch client: %v\n", ColorRed, ColorReset, err)
		return nil, err
	}

	// Channel to collect results from all goroutines
	resultsChan := make(chan HostResult, maxConcurrentScans)

	var wg sync.WaitGroup
	sem := make(chan struct{}, maxConcurrentScans)

	// Start a goroutine to print and save results as they come in
	processWg := &sync.WaitGroup{}
	processWg.Add(1)
	var hostCount int
	go func() {
		defer processWg.Done()
		for result := range resultsChan {
			hostCount++
			printResult(result)

			// Index to Elasticsearch immediately
			indexResultToES(es, result)
		}
	}()

	// Start scanning goroutines
	for Key, ip := range hostList.Hosts {
		wg.Add(1)
		fmt.Printf("\n\n ip: %v\n\n\n", ip.String())
		go scanHost(Key, &wg, sem, resultsChan)
	}

	// Wait for all scans to complete, then close the results channel
	wg.Wait()
	close(resultsChan)

	// Wait for the processing goroutine to finish
	processWg.Wait()

	fmt.Printf("\n%s[+]%s Scan complete. Scanned %d hosts. Results indexed to Elasticsearch.\n", ColorGreen, ColorReset, hostCount)

	return &scanner.PortResults{
		Results: []*scanner.PortResults_PortStatus{
			&scanner.PortResults_PortStatus{Port: maxConcurrentScans, Service: generateID(), IsOpen: true},
		},
	}, nil
}

func parsePortRange(portRange string) ([]int, error) {
	// معالجة نطاقات مثل "1-1024" أو "80,443,22"
	return []int{22, 80, 443}, nil // مثال مبسط
}

func getServiceName(port int) string {
	// خريطة بسيطة لأرقام المنافذ وأسماء الخدمات
	services := map[int]string{
		22:  "ssh",
		80:  "http",
		443: "https",
	}
	return services[port]
}

func isPortOpen(ip string, port int) bool {
	// محاكاة المسح - في الواقع ستستخدم net.DialTimeout
	return port != 25 // مثال: جميع المنافذ مفتوحة عدا 25
}

func main() {
	// Create discovery client first
	discoveryClient, err := newDiscoveryClient("localhost:50051") // host_discovery service address
	if err != nil {
		log.Fatalf("failed to create discovery client: %v", err)
	}

	// Create port scanner server
	lis, err := net.Listen("tcp", ":50052")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	scanner.RegisterPortScannerServer(s, &portScannerServer{
		discoveryClient: discoveryClient,
	})

	log.Printf("Port Scanner Server listening at %v", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
