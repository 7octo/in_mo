package main

import (
	"log"
	"os"

	"github.com/fsnotify/fsnotify"
)

func watchFileChanges(filename string, callback func()) {
	watcher, _ := fsnotify.NewWatcher()
	defer watcher.Close()

	watcher.Add(filename)
	for {
		select {
		case event := <-watcher.Events:
			if event.Op&fsnotify.Write == fsnotify.Write {
				callback()
			}
		case err := <-watcher.Errors:
			log.Println("Error watching file:", err)
		}
	}
}

func checkFileExists(filename string) {
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		log.Printf("Warning: IP file '%s' does not exist, creating empty file", filename)
		file, err := os.Create(filename)
		if err != nil {
			log.Fatalf("Failed to create IP file: %v", err)
		}
		file.Close()
	}
}

// في main():
// checkFileExists("ips.txt")
