package main

import (
	"bufio"
	"context"
	"flag"
	"log"
	"os"
	"time"

	pb "distributed-scan/scannerBuf"

	"google.golang.org/grpc"
)

func readIPs(filePath string) []string {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatalf("Failed to open file: %v", err)
	}
	defer file.Close()

	var ips []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		ips = append(ips, scanner.Text())
	}
	return ips
}

func main() {
	filePath := flag.String("f", "", "Path to file with IPs")
	flag.Parse()

	if *filePath == "" {
		log.Fatal("You must specify -f filename")
	}

	ips := readIPs(*filePath)

	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("Could not connect: %v", err)
	}
	defer conn.Close()

	client := pb.NewHostServiceClient(conn)

	for _, ip := range ips {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()

		res, err := client.SendIP(ctx, &pb.IPRequest{Ip: ip})
		if err != nil {
			log.Printf("❌ Error for %s: %v\n", ip, err)
		} else {
			log.Printf("📡 %s → %s (%v)\n", ip, res.Message, res.Alive)
		}
	}
}
