package main

import (
	"os"
	"sync"
)

// -------- CONFIG -------- //
const (
	Threads    = 10               // Number of parallel IP scans
	OutputFile = ""               // File to save active IPs (realtime)
	RangeFile  = "ip_ranges2.txt" // File to read IP ranges from
)

var ScanMethods = map[string]string{
	"ICMP Echo":         "-sn -PE",
	"ICMP Timestamp":    "-sn -PP",
	"ICMP Address Mask": "-sn -PM",
	"TCP SYN":           "-sn -PS80,443,22",
	"UDP":               "-sn -PU53,161,123",
}

// --- IP Logger ---
type UniqueIPLogger struct {
	filename string
	seen     map[string]struct{}
	mu       sync.Mutex
	file     *os.File
}
