package main

import (
	"context"
	scanner "distributed-scan/scannerBuf"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"

	"google.golang.org/grpc"
)

type sharedData struct {
	mu  sync.Mutex
	IPs []string
}
type server struct {
	scanner.UnimplementedHostServiceServer
	data *sharedData
}
type hostDiscoveryServer struct {
	scanner.UnimplementedHostDiscoveryServer
	data       *sharedData
	allResults map[string]map[string]bool
}

//	type server struct {
//		scanner.UnimplementedHostServiceServer
//		mu  sync.Mutex
//		ips []string
//	}
type All struct {
	server
	hostDiscoveryServer
}

func (s *server) SendIP(ctx context.Context, req *scanner.IPRequest) (*scanner.IPResponse, error) {
	ip := req.Ip

	// أضف IP للقائمة بطريقة آمنة
	s.data.mu.Lock()
	s.data.IPs = append(s.data.IPs, ip)
	s.data.mu.Unlock()

	// Convert to protobuf format
	return &scanner.IPResponse{
		Message: "",
		Alive:   true,
	}, nil
}
func (h *hostDiscoveryServer) DiscoverHosts(ctx context.Context, req *scanner.NetworkRange) (*scanner.HostList, error) {
	log.Printf("Received discovery request for network: %s", req.Cidr)

	h.data.mu.Lock()
	ips := make([]string, len(h.data.IPs))
	copy(ips, h.data.IPs)
	h.data.mu.Unlock()
	allIPs := ips
	logger, err := NewUniqueIPLogger(OutputFile)
	if err != nil {
		fmt.Printf("[!] Could not create output file: %v\n", err)
		return nil, fmt.Errorf("[!] Could not create output file: %v\n", err)
	}
	defer logger.Close()

	fmt.Printf("[*] Starting host discovery for %d total IPs.\n", len(allIPs))
	fmt.Printf("[*] Using methods: %s\n", strings.Join(getMethodNames(), ", "))
	totalIPs := len(allIPs)
	threads := 100 // Adjust based on your needs
	allResults := make(map[string]map[string]bool)
	processedIPs := 0

	// Process in batches
	for i := 0; i < totalIPs; i += threads {
		// Check if context was cancelled
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}

		end := i + threads
		if end > totalIPs {
			end = totalIPs
		}
		batch := allIPs[i:end]

		log.Printf("Scanning batch %d-%d of %d IPs", i+1, end, totalIPs)

		// Scan the batch concurrently
		batchResults := scanIPs(batch, logger)

		// Merge results from batch into allResults
		for ip, res := range batchResults {
			allResults[ip] = res
		}

		processedIPs += len(batch)
		log.Printf("Batch complete. Processed %d of %d IPs. Found %d active hosts",
			processedIPs, totalIPs, len(allResults))
	}

	return convertToHostList(allResults), nil
}

func main() {

	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("Failed to listen: %v", err)
	}
	//
	grpcServer := grpc.NewServer()
	ser := &server{
		data: &sharedData{
			IPs: make([]string, 0),
			mu:  sync.Mutex{},
		},
	}
	//
	scanner.RegisterHostServiceServer(grpcServer, ser)
	log.Println("✅ gRPC Server running on :50051")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("Failed to serve: %v", err)
	}

	//
	//
	//

	lis2, err := net.Listen("tcp", ":50052")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	scanner.RegisterHostDiscoveryServer(s, &hostDiscoveryServer{})

	log.Printf("Host Discovery Server listening at %v", lis.Addr())
	if err := s.Serve(lis2); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}

}
