package main

import (
	"bufio"
	"bytes"
	"context"
	scanner "distributed-scan/scannerBuf"
	"fmt"
	"net"
	"os"
	"os/exec"
	"sort"
	"strings"
	"sync"
	"time"
)

func NewUniqueIPLogger(filename string) (*UniqueIPLogger, error) {
	f, err := os.Create(filename)
	if err != nil {
		return nil, err
	}
	return &UniqueIPLogger{
		filename: filename,
		seen:     make(map[string]struct{}),
		file:     f,
	}, nil
}

func (l *UniqueIPLogger) Log(ip string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if _, exists := l.seen[ip]; !exists {
		l.seen[ip] = struct{}{}
		l.file.WriteString(ip + "\n")
	}
}

func (l *UniqueIPLogger) Count() int {
	l.mu.Lock()
	defer l.mu.Unlock()
	return len(l.seen)
}

func (l *UniqueIPLogger) Close() {
	l.file.Close()
}

// --- Core Scanning Logic ---

// isHostUp checks if a single IP is responsive to a given nmap scan method.
func isHostUp(ip, args string) bool {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	cmdArgs := append(strings.Split(args, " "), ip)
	cmd := exec.CommandContext(ctx, "sudo", append([]string{"nmap", "-n"}, cmdArgs...)...)

	output, _ := cmd.CombinedOutput()
	if ctx.Err() == context.DeadlineExceeded {
		return false
	}
	return strings.Contains(string(output), "Host is up")
}

// scanIPs takes a BATCH of IPs and scans them concurrently.
func scanIPs(ips []string, logger *UniqueIPLogger) map[string]map[string]bool {
	type job struct{ ip string }
	type result struct {
		ip      string
		results map[string]bool
		isUp    bool
	}

	numWorkers := len(ips)
	if numWorkers == 0 {
		return make(map[string]map[string]bool)
	}

	jobs := make(chan job, numWorkers)
	resultsChan := make(chan result, numWorkers)

	var wg sync.WaitGroup
	// Create one worker per IP in the batch
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func() { // This worker scans ONE IP
			defer wg.Done()
			for j := range jobs {
				// For this single IP, scan with all methods concurrently
				var methodWg sync.WaitGroup
				methodResultsChan := make(chan struct {
					name string
					isUp bool
				}, len(ScanMethods))

				for methodName, methodArgs := range ScanMethods {
					methodWg.Add(1)
					go func(name, args string) {
						defer methodWg.Done()
						if isHostUp(j.ip, args) {
							methodResultsChan <- struct {
								name string
								isUp bool
							}{name, true}
						} else {
							methodResultsChan <- struct {
								name string
								isUp bool
							}{name, false}
						}
					}(methodName, methodArgs)
				}

				methodWg.Wait()
				close(methodResultsChan)

				// Consolidate results for the IP
				ipResults := make(map[string]bool)
				var hostIsUp bool
				for res := range methodResultsChan {
					ipResults[res.name] = res.isUp
					if res.isUp {
						hostIsUp = true
					}
				}

				if hostIsUp {
					logger.Log(j.ip)
				}
				resultsChan <- result{ip: j.ip, results: ipResults, isUp: hostIsUp}
			}
		}()
	}

	for _, ip := range ips {
		jobs <- job{ip: ip}
	}
	close(jobs)

	wg.Wait()
	close(resultsChan)

	// Collect results from the batch
	finalResults := make(map[string]map[string]bool)
	for r := range resultsChan {
		if r.isUp {
			finalResults[r.ip] = r.results
		}
	}
	return finalResults
}

// --- IP Range Parsing ---

// inc increments an IP address.
func inc(ip net.IP) {
	for j := len(ip) - 1; j >= 0; j-- {
		ip[j]++
		if ip[j] > 0 {
			break
		}
	}
}

// expandCIDR returns all IP addresses in a CIDR range.
func expandCIDR(cidr string) ([]string, error) {
	ip, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		return nil, err
	}

	var ips []string
	for ip := ip.To4(); ipnet.Contains(ip); inc(ip) {
		ips = append(ips, ip.String())
	}

	ones, bits := ipnet.Mask.Size()
	if bits == 32 && ones < 31 && len(ips) > 2 {
		return ips[1 : len(ips)-1], nil
	}
	return ips, nil
}

// expandDashRange returns all IPs in a dash-separated range.
func expandDashRange(start, end net.IP) []string {
	var ips []string
	current := make(net.IP, len(start))
	copy(current, start)

	for bytes.Compare(current, end) <= 0 {
		ips = append(ips, current.String())
		inc(current)
	}
	return ips
}

// loadIPsFromFile parses all ranges and returns a single flat list of IPs.
func loadIPsFromFile(filename string) []string {
	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("[!] Could not open range file: %v\n", err)
		return nil
	}
	defer file.Close()

	var allIPs []string
	ipSet := make(map[string]struct{}) // Use a set to handle overlaps
	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var ipsToAdd []string
		if strings.Contains(line, "-") {
			parts := strings.Split(line, "-")
			if len(parts) == 2 {
				start := net.ParseIP(strings.TrimSpace(parts[0]))
				end := net.ParseIP(strings.TrimSpace(parts[1]))
				if start != nil && end != nil {
					ipsToAdd = expandDashRange(start, end)
				}
			}
		} else {
			ipsToAdd, _ = expandCIDR(line)
		}

		for _, ip := range ipsToAdd {
			if _, exists := ipSet[ip]; !exists {
				ipSet[ip] = struct{}{}
				allIPs = append(allIPs, ip)
			}
		}
	}
	return allIPs
}

// --- Reporting ---

func printReport(hostResults map[string]map[string]bool) {
	if len(hostResults) == 0 {
		fmt.Println("\n[!] No active hosts discovered.")
		return
	}

	methodNames := make([]string, 0, len(ScanMethods))
	for name := range ScanMethods {
		methodNames = append(methodNames, name)
	}
	sort.Strings(methodNames)

	headers := []string{"Host"}
	headers = append(headers, methodNames...)

	var table [][]string
	sortedIPs := make([]string, 0, len(hostResults))
	for ip := range hostResults {
		sortedIPs = append(sortedIPs, ip)
	}
	sort.Strings(sortedIPs)

	for _, ip := range sortedIPs {
		res := hostResults[ip]
		row := []string{ip}
		for _, m := range methodNames {
			if res[m] {
				row = append(row, "✔")
			} else {
				row = append(row, "✘")
			}
		}
		table = append(table, row)
	}

	fmt.Printf("\n[+] Host Discovery Results:\n")
	for _, h := range headers {
		fmt.Printf("%-20s", h)
	}
	fmt.Println()
	fmt.Println(strings.Repeat("-", 20*len(headers)))

	for _, row := range table {
		for _, cell := range row {
			fmt.Printf("%-20s", cell)
		}
		fmt.Println()
	}
}

func getMethodNames() []string {
	methods := make([]string, 0, len(ScanMethods))
	for m := range ScanMethods {
		methods = append(methods, m)
	}
	sort.Strings(methods)
	return methods
}

func convertToHostList(hostMap map[string]map[string]bool) *scanner.HostList {
	hostList := &scanner.HostList{
		Hosts: make(map[string]*scanner.HostList_HostInfo),
	}

	for host, ports := range hostMap {
		hostInfo := &scanner.HostList_HostInfo{
			Ports: make(map[string]bool),
		}
		for port, isOpen := range ports {
			hostInfo.Ports[port] = isOpen
		}
		hostList.Hosts[host] = hostInfo
	}

	return hostList
}

func convertFromHostList(hostList *scanner.HostList) map[string]map[string]bool {
	hostMap := make(map[string]map[string]bool)

	for host, hostInfo := range hostList.Hosts {
		portMap := make(map[string]bool)
		for port, isOpen := range hostInfo.Ports {
			portMap[port] = isOpen
		}
		hostMap[host] = portMap
	}

	return hostMap
}
