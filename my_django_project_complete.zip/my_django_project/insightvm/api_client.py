# Example API client to fetch data from external service
import requests

def fetch_data():
    response = requests.get("https://example.com/api")
    return response.json()
