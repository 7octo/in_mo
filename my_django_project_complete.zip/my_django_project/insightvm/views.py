from django.shortcuts import render
from .models import ScanResult

def index(request):
    results = ScanResult.objects.all()
    return render(request, "insightvm/example.html", {"results": results})
