from django.contrib import admin
from .models import ScanResult

admin.site.register(ScanResult)
