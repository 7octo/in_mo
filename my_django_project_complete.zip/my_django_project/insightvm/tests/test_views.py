from django.test import TestCase, Client

class InsightVMViewTests(TestCase):
    def test_index_view(self):
        client = Client()
        response = client.get("/insightvm/")
        self.assertEqual(response.status_code, 200)
